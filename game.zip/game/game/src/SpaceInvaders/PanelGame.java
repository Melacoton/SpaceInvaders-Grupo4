package SpaceInvaders;

import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.awt.Graphics;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.awt.Image;

public class PanelGame extends JPanel implements ActionListener, KeyListener {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
 
    private int playerX = 375;
    private int playerY = 490;
    
    private int playerWidth = 40, playerHeight = 60;
    private ArrayList<int[]> shots = new ArrayList<>();
    private ArrayList<int[]> enemies = new ArrayList<>();
    private ArrayList<int[]> enemyShots = new ArrayList<>();
    private ArrayList<int[]> enemiesRandall = new ArrayList<>();
private long LastShotTime = 0;
    private long ShootCooldown = 300;
    private boolean moveleft = false;
    private boolean moveright = false;
    private int enemyDirection = 1;
    private int enemySpeed = 1;
    
    private Timer timer;
    private int score = 0;  
    private int level = 0;
    private int acumEnemigos = 10;
    private int moveDownDelay = 0;
    private boolean isGameOver = false;
    private int vidas = 3;

    private Image playerI;
    private Image shotI;
    private Image enemieI;
    private Image fondoI;
    private Image gameOver;
    private Image enemieIRandall;
    private Image dosVidas;
    private Image unaVida;
    private Image sinVidas;
    private Image sullivan;
    private Image WIN;
    
    private Timer randallTimer;
    private boolean randallVisible = true;
    private static final int randallTImepo = 900; 
    private Timer vidaTimer;
    private boolean vidaVisible = true;
    private static final int vidaTiempo = 1200; 
    
    
    public PanelGame() {
       // setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);
        timer = new Timer(10, this);
        timer.start();
        generateEnemies();

        playerI = new ImageIcon("src/imagenes/nena.png").getImage();
        shotI = new ImageIcon("src/imagenes/cokie.png").getImage();
        enemieI = new ImageIcon("src/imagenes/mike.png").getImage();
        fondoI = new ImageIcon("src/imagenes/boo.png").getImage();
        sullivan = new ImageIcon("src/imagenes/sullivan.png").getImage();
        gameOver = new ImageIcon("src/imagenes/gameOver.png").getImage();
        enemieIRandall = new ImageIcon("src/imagenes/randall.png").getImage();
        dosVidas = new ImageIcon("src/imagenes/dosVidas.png").getImage();
        unaVida = new ImageIcon("src/imagenes/unaVida.png").getImage();
        sinVidas = new ImageIcon("src/imagenes/sinVidas.png").getImage();
        WIN = new ImageIcon("src/imagenes/WIN.png").getImage();
        
        randallTimer = new Timer(randallTImepo, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	randalVisibilidad();
            }
        });
        randallTimer.start();
        
        vidaTimer = new Timer(vidaTiempo, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	vidaVisible = false;
                repaint();
                vidaTimer.stop();
            }
        });
        vidaTimer.setRepeats(false);
    }


private void randalVisibilidad() {
        randallVisible = !randallVisible;
        repaint();
    }

    

private void generateEnemies() {
        int enemyY = 50;
        int enemySpacing = 70;
        for (int i = 0; i < 10; i++) {
        	acumEnemigos=0;
        	if(level==0) {
                enemies.add(new int[]{i * enemySpacing + 50, enemyY=50, 1});	
                acumEnemigos=10;
        	}
        	if(level == 1) {
        		enemies.add(new int[]{i * enemySpacing + 50, enemyY=50, 1});
                acumEnemigos=10;
            	}
            	if(level == 2) {
            	enemies.add(new int[]{i * enemySpacing + 50, enemyY=50, 1});
            	enemies.add(new int[]{i * enemySpacing + 50, enemyY=100, 1});
                acumEnemigos=20;
            	}
            	if(level == 3) {
            	enemies.add(new int[]{i * enemySpacing + 50, enemyY=50, 1});
            	enemies.add(new int[]{i * enemySpacing + 50, enemyY=100, 1});
            	acumEnemigos=20;
            	}
            	if(level==4) {
            		enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=20, 1});
            		enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=90, 1});
            		enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=150, 1});
                	enemies.add(new int[]{i * enemySpacing + 50, enemyY=220, 1});  
            		acumEnemigos=40;
            	}
            	if(level==5) {
                	enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=30, 1});
            		enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=100, 1});
                	enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=160, 1});
            		enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=230, 1});
                	enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=300, 1});
            		acumEnemigos=50;
            	}
        }
    }

private void checkGameOver() {
        for (int[] enemy : enemies) {
            if (enemy[1] + 30 >= playerY) {  // 30 es la altura de los enemigos
            	checkvida();
                repaint();
                break;
            }
            for (int[] enemyR : enemiesRandall) {
                if (enemyR[1] + 30 >= playerY) {  // 30 es la altura de los enemigos
                	checkvida();
                    repaint();
                    break;
                }
        }
        }
}
private void checkvida(){
	int enemyY = 50;
    int enemySpacing = 70;
		vidas--;
        enemies.clear();
        enemiesRandall.clear();
        if(vidas == 0) {
        	isGameOver = true;
        	timer.stop();
        }
        if (vidas == 0 || vidas == 2 || vidas == 1) {
        	vidaVisible = true;
            vidaTimer.restart();
        }
        
        for (int i = 0; i < 10; i++) {
        	acumEnemigos=0;
        	if(level==0) {
                enemies.add(new int[]{i * enemySpacing + 50, enemyY=50, 1});	
                acumEnemigos=10;
        	}
        	if(level == 1) {
        		enemies.add(new int[]{i * enemySpacing + 50, enemyY=50, 1});
                acumEnemigos=10;
            	}
            	if(level == 2) {
            	enemies.add(new int[]{i * enemySpacing + 50, enemyY=50, 1});
            	enemies.add(new int[]{i * enemySpacing + 50, enemyY=100, 1});
                acumEnemigos=20;
            	}
            	if(level == 3) {
            	enemies.add(new int[]{i * enemySpacing + 50, enemyY=50, 1});
            	enemies.add(new int[]{i * enemySpacing + 50, enemyY=100, 1});
            	acumEnemigos=20;
            	}
            	if(level==4) {
            		enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=20, 1});
            		enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=90, 1});
            		enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=150, 1});
                	enemies.add(new int[]{i * enemySpacing + 50, enemyY=220, 1});  
            		acumEnemigos=40;
            	}
            	if(level==5) {
                	enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=30, 1});
            		enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=100, 1});
                	enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=160, 1});
            		enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=230, 1});
                	enemiesRandall.add(new int[]{i * enemySpacing + 50, enemyY=300, 1});
            		acumEnemigos=50;
                }
                playerX = 375;
                playerY = 490;
                playerWidth = 40;
                playerHeight = 60;
        }
}
@Override
public void paintComponent(Graphics g) {
    super.paintComponent(g);
    g.drawImage(fondoI, 0, 0, getWidth(), getHeight(), this);
    g.drawImage(playerI, playerX, playerY, playerWidth, playerHeight, this);
   if(level == 5) {
    g.drawImage(sullivan, 150, playerY, playerWidth, playerHeight, this);
    g.drawImage(sullivan, 560, playerY, playerWidth, playerHeight, this);
   }
    for (int[] shot : shots) {
        g.drawImage(shotI, shot[0], shot[1], 20, 20, this);
    }
    for (int[] enemy : enemies) {
    	if(enemy.length > 2 && enemy[2] == 1) {
        g.drawImage(enemieI, enemy[0], enemy[1], 40, 40, this);
    	}
    }
    if (randallVisible) {
        for (int[] enemy : enemiesRandall) {
            if(enemy.length > 2 && enemy[2] == 1) {
                g.drawImage(enemieIRandall, enemy[0], enemy[1], 50, 50, this);
            }
        }
    }
    for (int[] enemyShot : enemyShots) {
    	g.setColor(Color.WHITE);
        g.fillRect(enemyShot[0], enemyShot[1], 5, 10);
    }
    g.setColor(Color.WHITE);
    g.setFont(new Font("Nirmala UI", Font.BOLD, 23));
    g.drawString("Puntuacion: " + score + " | Nivel: " + level, 3, 23);
    g.setColor(Color.WHITE);
    g.setFont(new Font("Nirmala UI", Font.BOLD, 23));
    g.drawString("Enemigos restantes: "+ acumEnemigos,  470, 540);
    g.setFont(new Font("Nirmala UI", Font.BOLD, 23));
    g.drawString("Vidas: "+ vidas,  50, 540);
    if (isGameOver) {
        g.drawImage(gameOver,  (getWidth() - 420) / 2,  (getHeight() - 30) / 2, 450, 90, this);
        g.drawImage(sinVidas,  310, 220, 150, 50, this);
    }
    if (vidaVisible && vidas == 2) {
        g.drawImage(dosVidas,  310, 220, 150, 50, this);
    }
    if (vidaVisible && vidas == 1) {
        g.drawImage(unaVida,  310, 220, 150, 50, this);
    }
    if(level == 6) {
        g.drawImage(WIN, 0, 0, getWidth(), getHeight(), this);
    }
   

}
    

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!isGameOver) {
            Iterator<int[]> iterator = shots.iterator();
            while (iterator.hasNext()) {
                int[] shot = iterator.next();
                shot[1] -= 5;
                shot[0] += shot[2];
                if (shot[1] < 0 || shot[0] < 0 || shot[0] > getWidth()) {
                    iterator.remove();
                } else {
                    Iterator<int[]> enemyIterator = enemies.iterator();
                    Iterator<int[]> randallIterator = enemiesRandall.iterator();
                    while (enemyIterator.hasNext()) {
                        int[] enemy = enemyIterator.next();
                        if (shot[0] >= enemy[0] && shot[0] <= enemy[0] + 30 && shot[1] >= enemy[1] && shot[1] <= enemy[1] + 30) {
                            enemyIterator.remove();
                            iterator.remove();
                            score= score + 10;
                            acumEnemigos--;
                            break;
                      
                        }
                    }
                    while (randallIterator.hasNext()) {
                        int[] enemyRandal = randallIterator.next();
                         if(shot[0] >= enemyRandal[0] && shot[0] <= enemyRandal[0] + 30 && shot[1] >= enemyRandal[1] && shot[1] <= enemyRandal[1] + 30) {
                             randallIterator.remove();
                             iterator.remove();
                             score= score + 10;
                             acumEnemigos--;
                             break;
                        }
                    }
                }
            }

            if (level >= 2) {
                Iterator<int[]> enemyShotIterator = enemyShots.iterator();
                while (enemyShotIterator.hasNext()) {
                    int[] enemyShot = enemyShotIterator.next();
                    enemyShot[1] += 5;
                    if (enemyShot[1] > getHeight()) {
                        enemyShotIterator.remove();
                    } else if (enemyShot[0] >= playerX && enemyShot[0] <= playerX + playerWidth && enemyShot[1] >= playerY && enemyShot[1] <= playerY + playerHeight) {
                    	enemyShotIterator.remove();
                    	checkvida();
                    	//  isGameOver = true;
                     //   timer.stop();
                    }
                }
                if (new Random().nextInt(100) < 5 && !enemies.isEmpty()) {
                    int[] randomEnemy = enemies.get(new Random().nextInt(enemies.size()));
                    enemyShots.add(new int[]{randomEnemy[0] + 15, randomEnemy[1] + 30});
                }
                if (new Random().nextInt(100) < 5 && !enemiesRandall.isEmpty()) {
                    int[] randomEnemy = enemiesRandall.get(new Random().nextInt(enemiesRandall.size()));
                    enemyShots.add(new int[]{randomEnemy[0] + 15, randomEnemy[1] + 30});
                }
            }
            if (level >= 1) {
                moveDownDelay++;
                if (moveDownDelay > 100) {
                    for (int[] enemy : enemies) {
                        enemy[1] += 10;
                    }
                    for (int[] enemy : enemiesRandall) {
                        enemy[1] += 10;
                    }
                    moveDownDelay = 5;
                }
            }

			if (level == 3 ) {
			    for (int[] enemy : enemies) {
			        if (enemy[0] + 30 / 2 >= playerX && enemy[0] + 30 / 2 <= playerX + playerWidth) {
			            if (enemy[1] < playerY - playerHeight) {
			                enemy[1] += 5;
			            } else if (enemy[1] + 30 >= playerY) {
			                isGameOver = true;
			                timer.stop();
			                break;
			            }
			        }
			    }
			    for (int[] enemy : enemiesRandall) {
			        if (enemy[0] + 30 / 2 >= playerX && enemy[0] + 30 / 2 <= playerX + playerWidth) {
			            if (enemy[1] < playerY - playerHeight) {
			                enemy[1] += 5;
			            } else if (enemy[1] + 30 >= playerY) {
			                isGameOver = true;
			                timer.stop();
			                break;
			            }
			        }
			    }
			}
			
			
        
			boolean shouldChangeDirection = false;
			
			if(level!=0) {
	        for (int[] enemy : enemies) {
	            enemy[0] += enemySpeed * enemyDirection;

	            if (enemy[0] <= 0 || enemy[0] >= getWidth() - 30) {
	                shouldChangeDirection = true;
	            }
	        }
	        for (int[] enemy : enemiesRandall) {
	            enemy[0] += enemySpeed * enemyDirection;

	            if (enemy[0] <= 0 || enemy[0] >= getWidth() - 30) {
	                shouldChangeDirection = true;
	            }
	        }

	        if (shouldChangeDirection) {
	            enemyDirection *= -1;
	            for (int[] enemy : enemies) {
	                enemy[1] += 1;
	            }
	            for (int[] enemy : enemiesRandall) {
	                enemy[1] += 1;
	            }
	        }
			}
            if (level <= 5 && acumEnemigos == 0) {
           	level++;
            generateEnemies();
            playerX = 375;
            playerY = 490;
            playerWidth = 40;
            playerHeight = 60;
           }
           
	 if (moveleft && playerX > 0) {
                playerX -= 3;
            }
            if (moveright && playerX < getWidth() - playerWidth) {
                playerX += 3;
            }

checkGameOver();

            repaint();
        }
    }

 @Override
    public void keyPressed(KeyEvent e) {
        if (!isGameOver) {
            if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                moveleft = true;
            }
            if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                moveright = true;
            }
            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                long currentTime = System.currentTimeMillis();
                if (currentTime - LastShotTime >= ShootCooldown) {
                    int speedX = 0;
                    if (moveleft) {
                        speedX = -2;
                    } else if (moveright) {
                        speedX = 2;
                    }
                    shots.add(new int[]{playerX + playerWidth / 2 - 2, playerY, speedX});
                    if(level == 5) {
                    shots.add(new int[]{150 + playerWidth / 2 - 2, 500, 0});
                    shots.add(new int[]{560 + playerWidth / 2 - 2, 500, 0});
                    }
                    LastShotTime = currentTime;
                }
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            moveleft = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            moveright = false;
        }
    }

 @Override
    public void keyTyped(KeyEvent e) {}
}