/**
 * 
 */
/**
 * @author Usuario
 *
 */
module game {
	requires java.desktop;
}