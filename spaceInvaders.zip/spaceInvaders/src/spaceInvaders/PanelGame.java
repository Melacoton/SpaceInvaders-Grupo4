package spaceInvaders;

import javax.swing.JPanel;
import javax.swing.ImageIcon;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Color;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.Timer;
import java.awt.Font;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;
import java.awt.Image;

public class PanelGame extends JPanel implements ActionListener, KeyListener {
    private int playerX = 375;
    private int playerY = 490;
    private int playerWidth = 50, playerHeight = 73;
    private ArrayList<int[]> shots = new ArrayList<>();
    private ArrayList<int[]> enemies = new ArrayList<>();
    private ArrayList<int[]> enemyShots = new ArrayList<>();

    private long LastShotTime = 0;
    private long ShootCooldown = 300;
    private boolean moveleft = false;
    private boolean moveright = false;
    
    private Timer timer;
    private int score = 0;
    private int level = 0;
    private int moveDownDelay = 0;
    private boolean isGameOver = false;
    
    private Image playerI;
    private Image shotI;
    private Image enemieI;
    private Image fondo;
    private Image gameOver;
    private Image nivel1;
    private Image nivel2;
    private Image nivel3;

    private int GameOverX = 193;
    private int GameOverY = 210;
    private int GameOverW = 400, GameOverH = 100;
    private Timer levelMensajeTimer;
    private static final int mensajeDuracion = 2000; 
    private boolean showLevelMensaje = false;
    
    public PanelGame() {
        setBackground(Color.BLACK);
        setFocusable(true);
        addKeyListener(this);
        timer = new Timer(10, this);
        timer.start();
        generateEnemies();
        
        levelMensajeTimer = new Timer(mensajeDuracion, new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
            	showLevelMensaje = false; 
            	levelMensajeTimer.stop(); 
            }
        });
        
        playerI = new ImageIcon(getClass().getResource("/Imagenes/buu.png")).getImage();
        shotI = new ImageIcon(getClass().getResource("/Imagenes/cook.png")).getImage();
        enemieI = new ImageIcon(getClass().getResource("/Imagenes/wasaski2.png")).getImage();
        fondo = new ImageIcon(getClass().getResource("/Imagenes/fondo1.png")).getImage();
        gameOver = new ImageIcon(getClass().getResource("/Imagenes/GameOver.png")).getImage();
        nivel1 = new ImageIcon(getClass().getResource("/Imagenes/Nivel1.png")).getImage();
        nivel2 = new ImageIcon(getClass().getResource("/Imagenes/Nivel2.png")).getImage();
        nivel3 = new ImageIcon(getClass().getResource("/Imagenes/Nivel3.png")).getImage();
    }

    private void generateEnemies() {
        int enemyY = 50;
        int enemySpacing = 70;
        for (int i = 0; i < 10; i++) {
            enemies.add(new int[]{i * enemySpacing + 50, enemyY});
        }
    }


private void checkGameOver() {
        for (int[] enemy : enemies) {
            if (enemy[1] + 30 >= playerY) {  // 30 es la altura de los enemigos
                isGameOver = true;
                timer.stop();
                repaint();
                break;
            }
        }
    }


    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2d = (Graphics2D) g;
        
        g.setColor(Color.WHITE);
        g2d.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
        g2d.drawImage(playerI, playerX, playerY, playerWidth, playerHeight, this);
        
        for (int[] shot : shots) {
            g2d.drawImage(shotI, shot[0], shot[1], 30, 20, this);
        }

        for (int[] enemy : enemies) {
            g2d.drawImage(enemieI, enemy[0], enemy[1], 60, 62, this);
        }

        for (int[] enemyShot : enemyShots) {
            g2d.drawImage(shotI, enemyShot[0], enemyShot[1], 30, 20, this);
        }
        
        g.setFont(new Font("Yu Gothic UI", Font.PLAIN, 25));
        g.drawString("Puntuación: " + score + " | Nivel: " + level, 3, 23);
        if (isGameOver) {
            g.drawImage(gameOver, GameOverX, GameOverY, GameOverW, GameOverH,  this);
        }
        if (showLevelMensaje && level==1) {
        	g.drawImage(nivel1, GameOverX, GameOverY, GameOverW, GameOverH,  this);
        }
        else if (showLevelMensaje && level==2) {
        	g.drawImage(nivel2, GameOverX, GameOverY, GameOverW, GameOverH,  this);
        }
        else if (showLevelMensaje && level==3) {
        	g.drawImage(nivel3, GameOverX, GameOverY, GameOverW, GameOverH,  this);
        }

    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (!isGameOver) {
            Iterator<int[]> iterator = shots.iterator();
            while (iterator.hasNext()) {
                int[] shot = iterator.next();
                shot[1] -= 5;
                shot[0] += shot[2];
if (shot[1] < 0 || shot[0] < 0 || shot[0] > getWidth()) {
                    iterator.remove();
                } else {
                    Iterator<int[]> enemyIterator = enemies.iterator();
                    while (enemyIterator.hasNext()) {
                        int[] enemy = enemyIterator.next();
                        if (shot[0] >= enemy[0] && shot[0] <= enemy[0] + 30 && shot[1] >= enemy[1] && shot[1] <= enemy[1] + 30) {
                            enemyIterator.remove();
                            iterator.remove();
                            score++;
                            break;
                        }
                    }
                }
            }


            
            if (level >= 2) {
                Iterator<int[]> enemyShotIterator = enemyShots.iterator();
                while (enemyShotIterator.hasNext()) {
                    int[] enemyShot = enemyShotIterator.next();
                    enemyShot[1] += 5;
                    if (enemyShot[1] > getHeight()) {
                        enemyShotIterator.remove();
                    } else if (enemyShot[0] >= playerX && enemyShot[0] <= playerX + playerWidth && enemyShot[1] >= playerY && enemyShot[1] <= playerY + playerHeight) {
                        isGameOver = true;
                        timer.stop();
                    }
                }
                if (new Random().nextInt(100) < 5 && !enemies.isEmpty()) {
                    int[] randomEnemy = enemies.get(new Random().nextInt(enemies.size()));
                    enemyShots.add(new int[]{randomEnemy[0] + 15, randomEnemy[1] + 30});
                }
            }
            if (level >= 1) {
                moveDownDelay++;
                if (moveDownDelay > 100) {
                    for (int[] enemy : enemies) {
                        enemy[1] += 10;
                    }
                    moveDownDelay = 0;
                }
            }

            if (level == 3) {
                for (int[] enemy : enemies) {
                    if (enemy[0] + 30 / 2 >= playerX && enemy[0] + 30 / 2 <= playerX + playerWidth) {
                        if (enemy[1] < playerY - playerHeight) {
                            enemy[1] += 5;
                        } else if (enemy[1] + 30 >= playerY) {
                            isGameOver = true;
                            timer.stop();
                            break;
                        }
                    }
                }
            }


            if (enemies.isEmpty()) {
                level++;
                generateEnemies();
                showLevelMensaje = true;
                levelMensajeTimer.start();
            }
	 if (moveleft && playerX > 0) {
                playerX -= 3;
            }
            if (moveright && playerX < getWidth() - playerWidth) {
                playerX += 3;
            }

checkGameOver();

            repaint();
        }
    }

 @Override
    public void keyPressed(KeyEvent e) {
        if (!isGameOver) {
            if (e.getKeyCode() == KeyEvent.VK_LEFT) {
                moveleft = true;
            }
            if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
                moveright = true;
            }
            if (e.getKeyCode() == KeyEvent.VK_SPACE) {
                long currentTime = System.currentTimeMillis();
                if (currentTime - LastShotTime >= ShootCooldown) {
                    int speedX = 0;
                    if (moveleft) {
                        speedX = -2;
                    } else if (moveright) {
                        speedX = 2;
                    }
                    shots.add(new int[]{playerX + playerWidth / 2 - 2, playerY, speedX});
                    LastShotTime = currentTime;
                }
            }
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode() == KeyEvent.VK_LEFT) {
            moveleft = false;
        }
        if (e.getKeyCode() == KeyEvent.VK_RIGHT) {
            moveright = false;
        }
    }

 @Override
    public void keyTyped(KeyEvent e) {}
}

