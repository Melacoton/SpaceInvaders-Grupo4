package spaceInvaders;

import javax.swing.JButton;
import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.event.ActionListener;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;

public class Menu extends JPanel {
    private static final long serialVersionUID = 1L;
    private JButton startButton;
    private Image backgroundImage;

    public Menu(ActionListener startAction, ActionListener exitAction) {
        setLayout(null); 
        setPreferredSize(new Dimension(776, 600));

        backgroundImage = new ImageIcon(getClass().getResource("/Imagenes/fondo1.png")).getImage();

        startButton = new JButton("Start Game");
        startButton.setBounds(295, 252, 191, 48);
        startButton.setFont(new Font("Arial", Font.BOLD, 18));
        startButton.setBackground(new Color(0, 0, 0));
        startButton.setForeground(Color.WHITE);
        startButton.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2));
        startButton.addActionListener(startAction);

        add(startButton);
        startButton.setIcon(new ImageIcon(Menu.class.getResource("/Imagenes/playBoton.png")));
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);

        if (backgroundImage != null) {
            Graphics2D g2d = (Graphics2D) g;
            g2d.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
        }
    }
}
